CREATE VIEW current_dept_emp AS
  SELECT
    `l`.`emp_no`    AS `emp_no`,
    `d`.`dept_no`   AS `dept_no`,
    `l`.`from_date` AS `from_date`,
    `l`.`to_date`   AS `to_date`
  FROM (`employees`.`dept_emp` `d`
    JOIN `employees`.`dept_emp_latest_date` `l`
      ON (((`d`.`emp_no` = `l`.`emp_no`) AND (`d`.`from_date` = `l`.`from_date`) AND (`l`.`to_date` = `d`.`to_date`))));
